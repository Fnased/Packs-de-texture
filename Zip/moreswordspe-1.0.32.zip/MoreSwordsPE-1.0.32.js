//More Swords Mod by Darkhax
//Official download from Darkhax.net

//Item ID values: If you get an ID conflict, you can change it here.
"use strict";
var DAWNSTAR_ID = 1610;
var DRACONIC_ID = 1611;
var ENDER_ID = 1612;
var GLACIAL_ID = 1613;
var GLADIOLUS_ID = 1614;
var VAMPIRIC_ID = 1616;
var WITHER_ID = 1617;
var AETHER_ID = 1618;
var ADMIN_ID = 1619;

//Durability values: If you want to change the durability of a sword, you can change it here.
var DAWNSTAR_DURABILITY = 1286;
var DRACONIC_DURABILITY = 1089;
var ENDER_DURABILITY = 1580;
var GLACIAL_DURABILITY = 680;
var GLADIOLUS_DURABILITY = 645;
var VAMPIRIC_DURABILITY = 812;
var WITHER_DURABILITY = 1869;
var AETHER_DURABILITY = 1796;
var ADMIN_DURABILITY = 9999999;

//Damage values: If you want to change the weapon damage of a sword, you can change it here.
var DAWNSTAR_DAMAGE = 6;
var DRACONIC_DAMAGE = 7;
var ENDER_DAMAGE = 8;
var GLACIAL_DAMAGE = 6;
var GLADIOLUS_DAMAGE = 6;
var VAMPIRIC_DAMAGE = 7;
var WITHER_DAMAGE = 8;
var AETHER_DAMAGE = 8;
var ADMIN_DAMAGE = 9999999;

//Recipe ID values: The following are a list IDs for the items used in crafting. Don't touch unless you know what you're doing!
var ID_SAPPLING = 6;
var ID_BEDROCK = 7;
var ID_LEAVES = 18;
var ID_FLOWER = 38;
var ID_OBSIDIAN = 49;
var ID_ICE = 79;
var ID_SOUL_SAND = 88;
var ID_GLOWSTONE = 89;
var ID_VINES = 106;
var ID_PACKED_ICE = 174;
var ID_DYE = 351;
var ID_DIAMOND = 264;
var ID_IRON_INGOT = 265;
var ID_STICK = 280;
var ID_FEATHER = 288;
var ID_REDSTONE = 331;
var ID_BLAZE_ROD = 369;
var ID_BLAZE_POWDER = 377;
var ID_MAGMA_CREAM = 378;

//And array containing the ID values of all swords that can appear randomly.
var itemArray = [DAWNSTAR_ID, DRACONIC_ID, ENDER_ID, GLACIAL_ID, GLADIOLUS_ID, VAMPIRIC_ID, WITHER_ID, AETHER_ID];

//The ID of the item currently held by the Player.
var currentItem = null;

//A function that handles the removal of health from an entity. 
//Authored by @TaQuItO_988 
Entity.removeHealth = function(entity, amount) {

    if (Entity.getHealth(entity) > amount && Entity.getHealth(entity) > 0)
        Entity.setHealth(entity, Entity.getHealth(entity) - amount);

    else if (Entity.getHealth(entity) <= amount && Entity.getHealth(entity) > 0)
        Entity.setHealth(entity, 1);
};

//A function that handles the removal of durability. The last parameter is optional and will default to 1.
//Authored by @TaQuItO_988 
Item.removeDurability = function(id, maxDurability, durabilityAmount) {

    if (Player.getCarriedItem() === id && Player.getCarriedItemData() < maxDurability - durabilityAmount || 1 && Level.getGameMode() === 0)
        Entity.setCarriedItem(Player.getEntity(), id, Player.getCarriedItemData() - durabilityAmount || 1, Player.getCarriedItemCount());

    else if (Player.getCarriedItem() === id && Player.getCarriedItemData() >= maxDurability - durabilityAmount || 1 && Level.getGameMode() === 0) {

        Entity.setCarriedItem(Player.getEntity(), id, 0, Player.getCarriedItemCount() - 1);
        Level.playSoundEnt(Player.getEntity(), "random.break");
    }
};

//A new Object to hold Sword data, and to handle various sword properties, such as durability and weapon damage.
//Authored by @TaQuItO_988 
var Sword = {

    itemsData: {},

    getDurability: function(id) {

        return Sword.itemsData[id].durability;
    },

    getDamage: function(id) {

        return Sword.itemsData[id].damage;
    },

    setDestroyTimes: function() {

        Block.setDestroyTime(18, 0.2 / 1.5);
        Block.setDestroyTime(30, 4 / 3.3 / 15);
        Block.setDestroyTime(86, 1 / 1.5);
        Block.setDestroyTime(91, 1 / 1.5);
        Block.setDestroyTime(103, 1 / 1.5);
        Block.setDestroyTime(106, 0.2 / 1.5);
        Block.setDestroyTime(127, 0.2 / 1.5);
    },

    resetDestroyTimes: function() {

        Block.setDestroyTime(18, 0.2);
        Block.setDestroyTime(30, 4);
        Block.setDestroyTime(86, 1);
        Block.setDestroyTime(91, 1);
        Block.setDestroyTime(103, 1);
        Block.setDestroyTime(106, 0.2);
        Block.setDestroyTime(127, 0.2);
    },

    changeItemHook: function(lastItem, newItem) {

        if (Item.isSword(newItem)) {

            this.setDestroyTimes();
            this.currentData = {
                "id": Player.getCarriedItem(),
                "durability": this.getDurability(Player.getCarriedItem()),
                "damage": this.getDamage(Player.getCarriedItem())
            };
        } else {

            this.resetDestroyTimes();
            this.currentData = {
                "id": null,
                "durability": null,
                "damage": null
            };
        }
    },

    destroyBlock: (x, y, z, s) => {

        Item.removeDurability(Player.getCarriedItem(), this.getDurability(Player.getCarriedItem()));

        if (Level.getGameMode() === 0) {

            switch (getTile(x, y, z)) {

                case 30:
                    Level.dropItem(x + 0.5, y, z + 0.5, 0, 287, 1, 0);
                    break;

                case 127:
                    Level.dropItem(x + 0.5, y, z + 0.5, 0, 351, 3, 3);
                    break;
            }
        } else
            preventDefault();
    },

    attackHook: function(a, v) {

        Entity.removeHealth(v, this.getDamage(Player.getCarriedItem()));
        Item.removeDurability(Player.getCarriedItem(), this.getDurability(Player.getCarriedItem()));
    }
};

//A function that will create a new Sword Item and register it into the game and Sword system. 
//This includes all the essential features, creative tabs, weapon damage and durability.
//Authored by @TaQuItO_988 
Item.defineSword = function(id, texture, textureDat, displayName, durability, damage) {

    ModPE.setItem(id, "sword_" + texture, textureDat, displayName, 1);
    Item.setCategory(id, ItemCategory.TOOL);
    Item.setMaxDamage(id, durability);
    Item.setHandEquipped(id, true);
    Player.addItemCreativeInv(id, 1);

    Sword.itemsData[id] = {

        "durability": durability,
        "damage": damage - 2
    };
};

//A function to check if an ID is associated with a valid Sword Item. 
//Authored by @TaQuItO_988 
Item.isSword = function(id) {

    if (Sword.itemsData[id] !== undefined)
        return true;

    else
        return false;
};

function newLevel() {

    clientMessage(ChatColor.WHITE + "More Swords by Dark" + ChatColor.GREEN + "hax");
}

function modTick() {

    //@TaQuItO_988 's Sword System integration.
    if (Player.getCarriedItem() !== currentItem) {

        changeItemHook(currentItem, Player.getCarriedItem());
        currentItem = Player.getCarriedItem();
    }
}

function attackHook(a, v) {

    var itemID = Player.getCarriedItem();

    //@TaQuItO_988 's Sword System integration.
    if (Item.isSword(itemID))
        Sword.attackHook(a, v);
    
    if (itemID == DAWNSTAR_ID)
        Entity.setFireTicks(v, 3);

    else if (itemID == DRACONIC_ID)
        Entity.removeAllEffects(v);

    else if (itemID == GLACIAL_ID)
        Entity.addEffect(v, MobEffect.movementSlowdown, 60, 1, false, true);

    else if (itemID == GLADIOLUS_ID)
        Entity.addEffect(v, MobEffect.poison, 100, 1, false, true);

    else if (itemID == VAMPIRIC_ID)
        Entity.addEffect(a, MobEffect.heal, 1, 1, false, true);

    else if (itemID == WITHER_ID)
        Entity.addEffect(v, MobEffect.wither, 100, 1, false, true);

    else if (itemID == AETHER_ID)
        Entity.setPosition(Entity.getX(v), Entity.getY(v) + 5 , Entity.getZ(v));
}

function changeItemHook(lastItem, newItem) {

    //@TaQuItO_988 's Sword System integration.
    if (Item.isSword(newItem) || Item.isSword(lastItem))
        Sword.changeItemHook(lastItem, newItem);
}

function destroyBlock(x, y, z, s) {

    //@TaQuItO_988 's Sword System integration.
    if (Item.isSword(Player.getCarriedItem()))
        Sword.destroyBlock(x, y, z, s);
}

function entityAddedHook(entity) {

    var entityID = Entity.getEntityTypeId(entity);
    
    if (entityID == EntityType.ZOMBIE && Math.random() < 0.75)
        Entity.setCarriedItem(entity, itemArray[Math.floor(Math.random() * itemArray.length), 1, 0]);
}

function procCmd(command) {

    var cmd = command.split(" ");

    if (cmd.length != 2)
            clientMessage(ChatColor.RED + "The moreswords command requires a second keyword. Keywords: swords, crafting!");
    
    if (cmd[0] == "moreswords") {

        clientMessage(cmd.length);
        
        if (Level.getGameMode() == 0) {

            if (cmd[1] == "swords") {

                addItemInventory(DAWNSTAR_ID, 1);
                addItemInventory(DRACONIC_ID, 1);
                addItemInventory(ENDER_ID, 1);
                addItemInventory(GLACIAL_ID, 1);
                addItemInventory(GLADIOLUS_ID, 1);
                addItemInventory(VAMPIRIC_ID, 1);
                addItemInventory(WITHER_ID, 1);
                addItemInventory(AETHER_ID, 1);
                addItemInventory(ADMIN_ID, 1);

                clientMessage(ChatColor.GREEN + "Added all swords to your inventory!");
            } 
            
            else if (cmd[1] == "crafting") {
                
                addItemInventory(ID_OBSIDIAN, 64);
                addItemInventory(ID_DYE, 64, 2);
                addItemInventory(ID_DIAMOND, 64);
                addItemInventory(ID_IRON_INGOT, 64);
                addItemInventory(ID_STICK, 64);
                addItemInventory(ID_REDSTONE, 64);
                addItemInventory(ID_BLAZE_ROD, 64);
                addItemInventory(ID_BLAZE_POWDER, 64);
                addItemInventory(ID_MAGMA_CREAM, 64);
                addItemInventory(ID_LEAVES, 64);
                addItemInventory(ID_VINES, 64);
                addItemInventory(ID_SAPPLING, 64);
                addItemInventory(ID_FLOWER, 64, 1);
                addItemInventory(ID_ICE, 64);
                addItemInventory(ID_PACKED_ICE, 64);
                addItemInventory(ID_FEATHER, 64);
                addItemInventory(ID_GLOWSTONE, 64);
                clientMessage(ChatColor.GREEN + "Added all crafting ingredients to your inventory!");
            }
        }

        if (Level.getGameMode() == 1)
            clientMessage(ChatColor.RED + "This command does not work in Creative mode!");
    }
}

Item.defineSword(DAWNSTAR_ID, "dawnStar", 0, ChatColor.GOLD + "Dawn Star", DAWNSTAR_DURABILITY, DAWNSTAR_DAMAGE);
Item.defineSword(DRACONIC_ID, "draconic", 0, ChatColor.DARK_PURPLE + "Draconic Blade", DRACONIC_DURABILITY, DRACONIC_DAMAGE);
Item.defineSword(ENDER_ID, "ender", 0, ChatColor.GREEN + "Eye End Sword", ENDER_DURABILITY, ENDER_DAMAGE);
Item.defineSword(GLACIAL_ID, "glacial", 0, ChatColor.BLUE + "Glacial Edge", GLACIAL_DURABILITY, GLACIAL_DAMAGE);
Item.defineSword(GLADIOLUS_ID, "gladiolus", 0, ChatColor.GREEN + "Gladiolus", GLADIOLUS_DURABILITY, GLADIOLUS_DAMAGE);
Item.defineSword(VAMPIRIC_ID, "vampiric", 0, ChatColor.RED + "Vampiric Blade", VAMPIRIC_DURABILITY, VAMPIRIC_DAMAGE);
Item.defineSword(WITHER_ID, "wither", 0, ChatColor.GRAY + "Wither's Bane", WITHER_DURABILITY, WITHER_DAMAGE);
Item.defineSword(AETHER_ID, "aether", 0, ChatColor.YELLOW + "Aether's Guard", AETHER_DURABILITY, AETHER_DAMAGE);
Item.defineSword(ADMIN_ID, "admin", 0, ChatColor.RED + "Adminium Ark", ADMIN_DURABILITY, ADMIN_DAMAGE);

Item.addShapedRecipe(DAWNSTAR_ID, 1, 0, [" ps", "psp", "rp "], ["p", ID_BLAZE_POWDER, 0, "s", ID_MAGMA_CREAM, 0, "r", ID_BLAZE_ROD, 0]);
Item.addShapedRecipe(DRACONIC_ID, 1, 0, [" ir", "ldi", "sl "], ["i", ID_IRON_INGOT, 0, "r", ID_REDSTONE, 0, "l", ID_DYE, 4, "s", ID_STICK, 0, "d", ID_DIAMOND, 0]);
Item.addShapedRecipe(VAMPIRIC_ID, 1, 0, [" ir", "ori", "so "], ["i", ID_IRON_INGOT, 0, "r", ID_REDSTONE, 0, "o", ID_OBSIDIAN, 0, "s", ID_STICK, 0]);
Item.addShapedRecipe(GLADIOLUS_ID, 1, 0, [" lv", "sfl", "rs "], ["l", ID_LEAVES, 0, "v", ID_VINES, 0, "s", ID_SAPPLING, 0, "f", ID_FLOWER, 1, "r", ID_STICK, 0]);
Item.addShapedRecipe(GLACIAL_ID, 1, 0, [" ip", "ipi", "si "], ["i", ID_ICE, 0, "p", ID_PACKED_ICE, 0, "s", ID_STICK, 0]);
Item.addShapedRecipe(AETHER_ID, 1, 0, ["fdg", "dgi", "sif"], ["f", ID_FEATHER, 0, "d", ID_DIAMOND, 0, "g", ID_GLOWSTONE, 0, "i", ID_IRON_INGOT, 0, "s", ID_STICK, 0]);
