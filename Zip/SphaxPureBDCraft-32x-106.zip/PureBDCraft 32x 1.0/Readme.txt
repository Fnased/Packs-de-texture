-----------------------
If you update Minecraft PE to 1.0.4 or higher,
you can't use the Texturpack in 1.0.3 or lower!!
-----------------------

Edited by Nikeey ^^