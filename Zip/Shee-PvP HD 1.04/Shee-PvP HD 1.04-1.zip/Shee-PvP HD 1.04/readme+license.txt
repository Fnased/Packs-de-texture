—README—

Shee-PvP HD is the premium resource pack for Minecrafters looking to up their game. If you have a combined love of sheep and PvP, there is clearly no need to look any further… right?
	
—MOD INFO—

This pack contains several features such as fullbright and custom animations which are only useable through external programs. It is worth using Optifine or MCPatcher for these features. For Shee-PvP I developed the most advanced fullbright lightmap than any other PvP resource pack.

—LICENSE—

This resource pack is Copyright ©2013 of WeeHeeHee and is the intellectual property of WeeHeeHee. Only Curse.com and Planetminecraft.com have my express permission to host downloads of the original and/or derived versions using resources sourced from this resource pack.
Any Upscaled textures included in Shee-PvP HD are excluded from this as they are under public domain.

You may not redistribute these textures, for profit, in your own packs, or otherwise. These conditions ARE ALL negotiable if you ask me.

In order to update this resource pack, visit:

http://weeheehee.com/#shee-pvp-hd
[Curse link coming soon]

-ATTRIBUTIONS-
Lamb with adult sheep image by Alan Cleaver. Permission given for use under CC license.
Lamb in hay by Paula Funnell. Permission given for use under CC license.
http://fxhome.com/sound-effects for their free Futuristic Gun Sounds which I sampled.
http://soundbible.com/1112-Toxic-Goo.html also sampled for the bow.
Sky texture by JerenVidsPC, used with permission.

If this resource pack and any contained resources breach copyright or if you have any other issues, please contact me at http://reddit.com/u/weeheehee or http://youtube.com/weeheeheeib

-CHANGELOG-
1.0 Initial release. Compiled from private Shee-PvP HD Addon and Upscaled.
1.01 Fixed golden sword texture
1.02 Fixed bow animation
	Added alternative diamond_sword.json model files
1.03 Bikini armor fix for Minecraft 1.8 as alternate armor files
1.04 New panorama modelled in Blender.